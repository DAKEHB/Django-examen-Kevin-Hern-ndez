from django.contrib import admin
from . models import Alumnos

admin.site.register(Alumnos)

# Register your models here.
